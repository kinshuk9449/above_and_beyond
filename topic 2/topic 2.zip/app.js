

    const clr = JSON.parse(localStorage.getItem('clr')) || [];
    function Changecolor(){
    var red = document.getElementById('rangeRed').value ;
    var blue = document.getElementById('rangeBlue').value ;
    var green = document.getElementById('rangeGreen').value ;
    var color = 'rgb('+red+','+green+','+blue+')';
    clr[0] = color;
    localStorage.setItem('clr', JSON.stringify(clr));
    document.getElementById("result").innerText = clr[0];

    var light_id;
    if(document.getElementById('ligh1').checked) {  


        document.getElementById('light1').style.color = clr[0];
        document.getElementById("result").innerText = clr[0];

    }   
    else if(document.getElementById('ligh2').checked) {   
        
        document.getElementById('light2').style.color = clr[0];
        document.getElementById("result").innerText = clr[0];

    }   
    else if(document.getElementById('ligh3').checked) {   
        
        document.getElementById('light3').style.color = clr[0];
        document.getElementById("result").innerText = clr[0];

    }   
    else if(document.getElementById('ligh4').checked) {   

        document.getElementById('light4').style.color = clr[0];
        document.getElementById("result").innerText = clr[0];

    }  
    else {   
          
    }   
  
    document.getElementById('light1').style.color ="'"+clr[0]+"'";
    location.href = 'colour-change.html';
}